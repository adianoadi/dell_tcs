for(var i=0;i<(document.querySelectorAll(".drum")).length;i++)
{
    document.querySelectorAll("button")[i].addEventListener("click",fun1);
}

function fun1(){
    alert("Button got clicked!");
}